# baham-mobile

## Drawer

 ![Drawer](https://github.com/Cozumo/baham-mobile/assets/79846702/f6cde385-9565-406d-9868-bed55c777ca4) 

## Home

![Home](https://github.com/Cozumo/baham-mobile/assets/79846702/d5981756-525f-43df-b87d-7983ce701f6f)

## Settings

![Settings](https://github.com/Cozumo/baham-mobile/assets/79846702/ce1eb892-f4bc-4df4-8b16-cf54582dee48)

## About 

![About](https://github.com/Cozumo/baham-mobile/assets/79846702/73a896ad-e28e-4af2-afc3-ea73a816c507)
